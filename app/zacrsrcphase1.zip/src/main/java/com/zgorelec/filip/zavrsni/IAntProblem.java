package com.zgorelec.filip.zavrsni;

public interface IAntProblem {

    String[][] getProblemMap();
}
