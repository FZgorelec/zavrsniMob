package com.zgorelec.filip.zavrsni;

import android.content.Context;
import android.os.Handler;
import android.widget.ImageButton;

public class GameButton extends android.support.v7.widget.AppCompatImageButton {
    private String state;
    private  StateToImageMap stateToImageMap=StateToImageMap.getInstance();
    //Handler handler =new Handler();
    public GameButton(Context context,String state){
        super(context);
        this.state=state;
        setState(state);
    }

    public void setState(String state, Handler handler, int delay) {
        final Integer imageResource = stateToImageMap.getStateToImageMap().get(state);
        if (imageResource == null) {
            throw new IllegalArgumentException();
        } else {
            this.state = state;
            handler.postDelayed(() -> setBackgroundResource(imageResource), delay);

        }
    }
    public void setState(String state) {
        Integer imageResource=stateToImageMap.getStateToImageMap().get(state);
        if(imageResource==null){
            throw new IllegalArgumentException();
        }
        else{
            this.state=state;
            setBackgroundResource(imageResource);

        }
        /*
        switch (state){
            case "antUp":
                setBackgroundResource(R.drawable.game_ant_up72);
                break;
            case "antDown":
                setBackgroundResource(R.drawable.game_ant_down72);
                break;
            case "antRight":
                setBackgroundResource(R.drawable.game_ant_right72);
                break;
            case "antLeft":
                setBackgroundResource(R.drawable.game_ant_left72);
                break;
            case "bomb":
                setBackgroundResource(R.drawable.gamebomb72);
                break;
            case "food":
                setBackgroundResource(R.drawable.game_food72);
                break;
            case "openField":
                setBackgroundResource(R.drawable.gameopenfield72);
                break;
            case "wall":
                setBackgroundResource(R.drawable.gamewall72);
                break;
            default:
                throw new IllegalArgumentException();
         }
         this.state=state;
*/    }

    public String getState() {
        return state;
    }
}
