package com.zgorelec.filip.zavrsni;

import android.content.Context;

public class Game {
    Context context;
    private GUI gui=new GUI(context);
    public void initGame(Context context){

    }
    public void run(){

    }
}
