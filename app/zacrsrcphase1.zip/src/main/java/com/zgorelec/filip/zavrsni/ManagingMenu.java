package com.zgorelec.filip.zavrsni;

import android.content.Context;
import android.widget.Button;
import android.widget.TableRow;

import java.util.HashMap;
import java.util.Map;

public class ManagingMenu {

    private Context context;
    private MenuButton activeButton;
    private MenuButton aboutButton;
    private Map<String, MenuButton> boardManagingButtons = new HashMap<>();
    private MenuButton calculationButton;
    private TableRow managingTR;
    public ManagingMenu(Context context){
        this.context=context;
    }

    public TableRow initManagingTR() {
        managingTR = new TableRow(context);
        GUIUtils.rowParameters.weight=10;
        managingTR.setLayoutParams(GUIUtils.rowParameters);
        boardManagingButtons = new HashMap<>();
        boardManagingButtons.put("openField", new MenuButton(context,"openField"));
        boardManagingButtons.put("wall", new MenuButton(context,"wall"));
        boardManagingButtons.put("food", new MenuButton(context,"food"));
        boardManagingButtons.put("bomb", new MenuButton(context,"bomb"));
        boardManagingButtons.get("openField").setText("Open Field");
        boardManagingButtons.get("wall").setText("Wall");
        boardManagingButtons.get("food").setText("Food");
        boardManagingButtons.get("bomb").setText("Bomb");
        calculationButton=new MenuButton(context,"calculate");
        aboutButton=new MenuButton(context,"about");
        activeButton= boardManagingButtons.get("openField");
        for (MenuButton button : boardManagingButtons.values()) {
            GUIUtils.buttonSetup(button);
            button.setBackgroundResource(R.drawable.menu_button_background);
            managingTR.addView(button);
        }
        GUIUtils.buttonSetup(calculationButton);
        GUIUtils.buttonSetup(aboutButton);
        calculationButton.setBackgroundResource(R.drawable.menu_button_background);
        aboutButton.setBackgroundResource(R.drawable.menu_button_background);
        calculationButton.setText("Calculate");
        aboutButton.setText("About");

        managingTR.addView(calculationButton);
        managingTR.addView(aboutButton);
        return managingTR;
    }

    public MenuButton getAboutButton() {
        return aboutButton;
    }

    public MenuButton getCalculationButton() {
        return calculationButton;
    }

    public Button getActiveButton() {
        return activeButton;
    }

    public TableRow getManagingTR() {
        return managingTR;
    }

    public Map<String, MenuButton> getBoardManagingButtons() {
        return boardManagingButtons;
    }

    public void updateBoardManagmentButtons(Button button) {
        for (Button managmentButton:boardManagingButtons.values()) {
            managmentButton.setPressed(false);
        }
        button.setPressed(true);
    }
}
